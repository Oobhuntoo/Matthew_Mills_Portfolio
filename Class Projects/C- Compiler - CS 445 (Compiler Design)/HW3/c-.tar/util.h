
#ifndef _UTIL_H_
#define _UTIL_H_

#include "globals.h"
#include "stdio.h"


TreeNode * newNode(NodeKind general_kind, Kind specific_kind, Type t, int line, TokenData * token);



#endif
